/********************************************************
  Include these libraries
  These libraries are required for operation of the device
  They can be found here:
  https://hackaday.io/project/160742-homecage-activity-monitoring-with-pirs  
********************************************************/
#include <Adafruit_SSD1306.h>
#include <Wire.h>
#include <RTCZero.h>
#include <SPI.h>
#include <SdFat.h>
SdFat SD;             //Quick way to make SdFat work with standard SD.h sketches
#include <Adafruit_GFX.h>
#include <TimeLib.h> //include the Arduino Time library
#include <stdio.h>  // include the C++ standard IO library

/********************************************************
  Set up OLED screen
  These lines set up and reset the OLED screen
  These should not be changed.
********************************************************/
#define OLED_RESET 4
Adafruit_SSD1306 display(OLED_RESET);

/********************************************************
  Feather pins being used
  These denote the pins used for the LEDs, buttons, SD card, and sensor
  These should not be changed.
********************************************************/
#define RED_LED 13
#define GREEN_LED 8
#define PIR_PIN 15
#define VBATPIN A7
#define cardSelect 4
#define buttonA 9
#define buttonB 6
#define buttonC 5
#define powerPIR 1

/********************************************************
  Initialize variables
  Most of these variables should not be changed, except for logfreq.
  logfreq changes the logging frequency, which is in seconds.  
  by default it is set to 60s 
  
  The other variables should not be changed 
********************************************************/
int logfreq = 60;  // Change this to edit # of seconds between data points

//DON'T CHANGE VARIABLES BELOW HERE ****************
int PIRBoutDuration = 600;
int PIRCount = 0;
double PIRDuration = 0.0;
bool PIRActive = false;
bool logReady = false;
int logtimer = 0;
float measuredvbat = 1.00;
unsigned long BlinkMillis = millis();
unsigned long PIRmillis = millis();
unsigned long startmillis = millis();
char buf[21];
int SetSequence = 0;
int PIRCountChange=0;
double PIRDurationChange=0.0;
float PIRcalibration=0.0000325;

/********************************************************
  Setup RTC and filenames on SD card
  These variables are needed to initialize the filename
  on the SD card.  These should not be changed.
********************************************************/
RTCZero rtc;

void dateTime(uint16_t* date, uint16_t* time) {
  // return date using FAT_DATE macro to format fields
  *date = FAT_DATE(rtc.getYear() - 48, rtc.getMonth(), rtc.getDay());

  // return time using FAT_TIME macro to format fields
  *time = FAT_TIME(rtc.getHours(), rtc.getMinutes(), rtc.getSeconds());
}

File logfile;         // Create file object
File configfile;         // Create another file object
char filename[15];    // Array for file name data logged to named in setup
int PIR;

/********************************************************
  Setup date and time variables
  These variables are needed for proper operation of the RTC 
  and should not be changed
********************************************************/
char s_month[5];
int tmonth, tday, tyear, thour, tminute, tsecond;
static const char month_names[] = "JanFebMarAprMayJunJulAugSepOctNovDec";
unsigned long elapsed = ((millis() - startmillis) / 1000);
int runHours = elapsed / 3600;
int secsRemaining = elapsed % 3600;
int runMinutes = secsRemaining / 60;
int runSeconds = secsRemaining % 60;
